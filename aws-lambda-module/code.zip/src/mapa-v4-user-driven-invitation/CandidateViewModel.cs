﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace mapa_v4_user_driven_invitation
{
    public class CandidateViewModel
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Cpf { get; set; }
    }
}
