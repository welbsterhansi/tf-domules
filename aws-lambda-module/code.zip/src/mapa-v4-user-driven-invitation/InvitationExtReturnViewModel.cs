﻿using System;

namespace mapa_v4_user_driven_invitation
{
    public class InvitationExtReturnViewModel
    {
        public Data Data { get; set; }
    }

    public class Data
    {
        public string? test_url { get; set; }
        public string? hash { get; set; }
    }
}
