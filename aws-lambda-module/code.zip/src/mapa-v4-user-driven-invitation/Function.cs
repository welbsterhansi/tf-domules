using Amazon.Lambda.Core;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

namespace mapa_v4_user_driven_invitation
{

    public class Function
    {
        /// <summary>
        /// Cria convite com o nome e e-mail do usu�rio a ser avaliado
        /// </summary>
        /// <param name="invitation"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task<InvitationExtReturnViewModel> CreateInvitation(InvitationCandidateViewModel invitation, ILambdaContext context)
        {
            if (invitation != null)
            {
                InvitationExtViewModel invitationExt = new();
                invitationExt.TestId = Guid.Parse("f2c0098e-ac69-11eb-b911-ecf4bbf86728");
                invitationExt.UnitId = getUnitIdByAcronym(invitation.CityAcronym);
                invitationExt.PositionUnitId = getPositionUnitIdByAcronym(invitation.CityAcronym);
                invitationExt.SendEmail = true;
                invitationExt.Candidate = new CandidateViewModel();
                invitationExt.Candidate.Email = invitation.Email;
                invitationExt.Candidate.Name = invitation.Name;

                return await SendInvitation(invitationExt);
            }
            return null;
        }

        private static async Task<string> GetToken(Guid unitId)
        {
            try
            {
                string APIUrl = Environment.GetEnvironmentVariable("mapa-v4-lambda-test-integrator-url");
                using (var httpClient = new HttpClient())
                {
                    var contentPost = new StringContent(JsonConvert.SerializeObject(""), Encoding.UTF8, "application/json");
                    var extEndPointGetToken = $"{APIUrl}/api/auth/gettoken?companyId={unitId}";
                    var response = await httpClient.PostAsync(extEndPointGetToken, contentPost);

                    if (response.IsSuccessStatusCode)
                    {
                        string content = await response.Content.ReadAsStringAsync();
                        return JsonConvert.DeserializeObject<string>(content);
                    }
                    return null;
                }
            }

            catch (Exception e)
            {
                throw;
            }
        }


        private static async Task<InvitationExtReturnViewModel> SendInvitation(InvitationExtViewModel invitation)
        {
            string tokenExt = await GetToken(invitation.UnitId);
            try
            {
                string APIUrl = Environment.GetEnvironmentVariable("mapa-v4-lambda-test-integrator-url");
                using (var httpClient = new HttpClient())
                {
                    var content = new StringContent(JsonConvert.SerializeObject(invitation), Encoding.UTF8, "application/json");
                    content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", tokenExt);
                    var extEndPoint = $"{APIUrl}/api/invitation/";

                    var response = await httpClient.PostAsync(extEndPoint, content);
                    if (response.IsSuccessStatusCode)
                    {
                        string contentResult = await response.Content.ReadAsStringAsync();
                        return JsonConvert.DeserializeObject<InvitationExtReturnViewModel>(contentResult);
                    }
                    return null;
                }
            }

            catch (Exception e)
            {
                throw;
            }
        }

        private Guid getUnitIdByAcronym(string cityAcronym)
        {
            if (cityAcronym.Equals("ES"))
                return Guid.Parse("268e3417-c1f9-4f79-9958-08178633a95b");
            else if (cityAcronym.Equals("MG"))
                return Guid.Parse("9e38654d-b979-466e-a833-8b54c897abd");
            else if (cityAcronym.Equals("SP"))
                return Guid.Parse("4b348e6f-005c-4d96-9466-e1e641be6f0a");
            else if (cityAcronym.Equals("RJ"))
                return Guid.Parse("5f58a579-30bf-470f-a452-ac584e3c6583");
            else
                return Guid.Empty;
        }

        private Guid getPositionUnitIdByAcronym(string cityAcronym)
        {
            if (cityAcronym.Equals("ES"))
                return Guid.Parse("afe6daa8-ee0c-4fb7-0298-08da47d2bd08");
            else if (cityAcronym.Equals("MG"))
                return Guid.Parse("c6252e8f-64b9-4a72-0299-08da47d2bd08");
            else if (cityAcronym.Equals("SP"))
                return Guid.Parse("16859f50-1877-415b-84dc-08da47d2d633");
            else if (cityAcronym.Equals("RJ"))
                return Guid.Parse("107c81ec-8843-42bf-18de-08da47d2ce2e");
            else
                return Guid.Empty;
        }

    }
}