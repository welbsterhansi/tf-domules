﻿using System;

namespace mapa_v4_user_driven_invitation
{
    public class InvitationExtViewModel
    {
        public virtual CandidateViewModel Candidate { get; set; }
        public Guid TestId { get; set; }
        public Guid UnitId { get; set; }
        public Guid? PositionUnitId { get; set; }
        public string? ReturnUrl { get; set; }
        public string? CallBackUrl { get; set; }
        public string? ExternalId { get; set; }
        public bool SendEmail { get; set; }
        public Guid? ResponsibleId { get; set; }
    }
}
