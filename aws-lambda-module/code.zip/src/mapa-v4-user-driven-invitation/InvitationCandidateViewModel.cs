﻿using System;

namespace mapa_v4_user_driven_invitation
{
    public class InvitationCandidateViewModel
    {
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? CityAcronym { get; set; }
    }
}